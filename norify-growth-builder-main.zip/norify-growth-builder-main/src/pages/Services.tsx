import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  ArrowRight, Target, TrendingUp, Megaphone, Search, Palette, Globe, 
  CheckCircle2, Zap, BarChart3, MessageSquare, PenTool, Rocket
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import Layout from '@/components/layout/Layout';

const services = [
  {
    icon: Target,
    title: 'Digital Marketing Strategy',
    description: 'Comprehensive strategic planning that aligns marketing efforts with your business objectives.',
    benefits: [
      'Market research & competitive analysis',
      'Customer journey mapping',
      'Channel strategy & budget allocation',
      'KPI framework & measurement plan',
      'Quarterly strategy reviews',
    ],
    process: ['Discovery', 'Research', 'Strategy', 'Roadmap', 'Execute'],
  },
  {
    icon: Megaphone,
    title: 'Social Media Marketing',
    description: 'Build authentic connections and grow engaged communities across all major platforms.',
    benefits: [
      'Platform strategy & optimization',
      'Content creation & scheduling',
      'Community management',
      'Influencer partnerships',
      'Performance analytics',
    ],
    process: ['Audit', 'Strategy', 'Create', 'Engage', 'Analyze'],
  },
  {
    icon: TrendingUp,
    title: 'Performance Advertising',
    description: 'ROI-focused paid campaigns across Meta, Google, LinkedIn, and emerging platforms.',
    benefits: [
      'Campaign strategy & setup',
      'Audience targeting & segmentation',
      'Creative development & testing',
      'Bid optimization & management',
      'Conversion tracking & attribution',
    ],
    process: ['Research', 'Setup', 'Launch', 'Optimize', 'Scale'],
  },
  {
    icon: Search,
    title: 'SEO & Content Marketing',
    description: 'Dominate search rankings with strategic content that attracts and converts organic traffic.',
    benefits: [
      'Technical SEO audit & fixes',
      'Keyword research & mapping',
      'Content strategy & creation',
      'Link building & outreach',
      'Rank tracking & reporting',
    ],
    process: ['Audit', 'Keyword', 'Create', 'Optimize', 'Monitor'],
  },
  {
    icon: Palette,
    title: 'Branding & Creative Design',
    description: 'Visual identities that capture your brand essence and resonate with your target audience.',
    benefits: [
      'Brand strategy & positioning',
      'Logo & visual identity design',
      'Brand guidelines development',
      'Marketing collateral design',
      'Social media templates',
    ],
    process: ['Discover', 'Concept', 'Design', 'Refine', 'Deliver'],
  },
  {
    icon: Globe,
    title: 'Website & Funnel Optimization',
    description: 'Conversion-focused optimization that turns more visitors into customers.',
    benefits: [
      'Conversion rate optimization',
      'Landing page design',
      'A/B testing & experimentation',
      'User experience improvements',
      'Analytics & heatmap analysis',
    ],
    process: ['Analyze', 'Hypothesize', 'Test', 'Learn', 'Implement'],
  },
];

const whyChoose = [
  { icon: Zap, title: 'Fast Results', desc: 'See impact within weeks, not months.' },
  { icon: BarChart3, title: 'Data-Driven', desc: 'Every decision backed by analytics.' },
  { icon: MessageSquare, title: 'Transparent', desc: 'Regular updates and full visibility.' },
  { icon: Rocket, title: 'Scalable', desc: 'Solutions that grow with you.' },
];

const Services = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="pt-32 pb-20 md:pt-40 md:pb-28">
        <div className="container-custom px-4 md:px-8">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <span className="text-primary font-medium mb-4 block">Our Services</span>
            <h1 className="text-4xl md:text-6xl font-heading font-bold mb-8">
              Full-Service <span className="gradient-text">Digital Marketing</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Comprehensive solutions to grow your brand, engage your audience, 
              and accelerate your business growth.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services List */}
      <section className="pb-20">
        <div className="container-custom px-4 md:px-8">
          <div className="space-y-16">
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className={`grid lg:grid-cols-2 gap-12 items-center ${
                  index % 2 === 1 ? 'lg:flex-row-reverse' : ''
                }`}
              >
                <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center">
                      <service.icon className="w-7 h-7 text-primary" />
                    </div>
                    <h2 className="text-2xl md:text-3xl font-heading font-bold">{service.title}</h2>
                  </div>
                  <p className="text-lg text-muted-foreground mb-8">{service.description}</p>

                  <div className="space-y-3 mb-8">
                    {service.benefits.map((benefit) => (
                      <div key={benefit} className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                        <span className="text-muted-foreground">{benefit}</span>
                      </div>
                    ))}
                  </div>

                  <Button variant="hero" asChild>
                    <Link to="/contact">
                      Request This Service
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Link>
                  </Button>
                </div>

                <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                  <div className="p-8 rounded-3xl bg-card border border-border">
                    <h4 className="text-sm font-medium text-muted-foreground mb-6 uppercase tracking-wider">
                      Our Process
                    </h4>
                    <div className="flex items-center justify-between">
                      {service.process.map((step, i) => (
                        <div key={step} className="flex flex-col items-center">
                          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-sm font-semibold text-primary mb-2">
                            {i + 1}
                          </div>
                          <span className="text-xs text-muted-foreground">{step}</span>
                        </div>
                      ))}
                    </div>
                    <div className="mt-4 h-1 rounded-full bg-muted relative overflow-hidden">
                      <div className="absolute inset-y-0 left-0 w-full bg-gradient-to-r from-primary to-accent" />
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Section */}
      <section className="py-20 bg-secondary/30 border-y border-border">
        <div className="container-custom px-4 md:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-heading font-bold">
              Why <span className="gradient-text">Work With Us</span>
            </h2>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {whyChoose.map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center p-6"
              >
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <item.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-heading font-semibold mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-padding">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative rounded-3xl bg-gradient-to-r from-primary/20 to-accent/20 p-12 md:p-20 text-center"
          >
            <h2 className="text-3xl md:text-5xl font-heading font-bold mb-6">
              Not Sure Where to Start?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10">
              Book a free strategy call and we'll help you identify the best services for your goals.
            </p>
            <Button variant="hero" size="xl" asChild>
              <Link to="/contact">
                Get Free Consultation
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default Services;
