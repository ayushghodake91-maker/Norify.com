import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, ArrowRight, Clock, Calendar, User, Twitter, Facebook, Linkedin, Link2, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Layout from '@/components/layout/Layout';
import { getPostBySlug, getRelatedPosts, blogPosts } from '@/data/blogPosts';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';

const BlogPost = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);
  
  // Try to find by slug first, then by id for backward compatibility
  const post = getPostBySlug(slug || '') || blogPosts.find(p => p.id === Number(slug));
  const relatedPosts = post ? getRelatedPosts(post, 3) : [];

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  if (!post) {
    return (
      <Layout>
        <section className="pt-32 pb-20">
          <div className="container-custom px-4 text-center">
            <h1 className="text-4xl font-heading font-bold mb-4">Article Not Found</h1>
            <p className="text-muted-foreground mb-8">The article you're looking for doesn't exist.</p>
            <Button variant="hero" asChild>
              <Link to="/blog">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Blog
              </Link>
            </Button>
          </div>
        </section>
      </Layout>
    );
  }

  const shareUrl = typeof window !== 'undefined' ? window.location.href : '';
  const shareText = encodeURIComponent(post.title);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    toast.success('Link copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const shareLinks = {
    twitter: `https://twitter.com/intent/tweet?text=${shareText}&url=${encodeURIComponent(shareUrl)}`,
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`,
    email: `mailto:?subject=${shareText}&body=Check out this article: ${shareUrl}`,
  };

  // Convert markdown-like content to HTML
  const formatContent = (content: string) => {
    return content
      .split('\n')
      .map((line, i) => {
        if (line.startsWith('## ')) {
          return <h2 key={i} className="text-2xl md:text-3xl font-heading font-bold mt-10 mb-4 text-foreground">{line.replace('## ', '')}</h2>;
        }
        if (line.startsWith('### ')) {
          return <h3 key={i} className="text-xl md:text-2xl font-heading font-semibold mt-8 mb-3 text-foreground">{line.replace('### ', '')}</h3>;
        }
        if (line.startsWith('#### ')) {
          return <h4 key={i} className="text-lg font-heading font-semibold mt-6 mb-2 text-foreground">{line.replace('#### ', '')}</h4>;
        }
        if (line.startsWith('**') && line.endsWith('**')) {
          return <p key={i} className="font-semibold text-foreground mt-4 mb-2">{line.replace(/\*\*/g, '')}</p>;
        }
        if (line.startsWith('- ')) {
          return <li key={i} className="ml-6 text-muted-foreground list-disc">{line.replace('- ', '')}</li>;
        }
        if (line.startsWith('| ')) {
          // Simple table row handling
          const cells = line.split('|').filter(c => c.trim());
          if (cells.every(c => c.trim().match(/^-+$/))) return null;
          return (
            <div key={i} className="flex border-b border-border">
              {cells.map((cell, j) => (
                <div key={j} className="flex-1 py-2 px-3 text-sm text-muted-foreground">{cell.trim()}</div>
              ))}
            </div>
          );
        }
        if (line.match(/^\d+\. /)) {
          return <li key={i} className="ml-6 text-muted-foreground list-decimal">{line.replace(/^\d+\. /, '')}</li>;
        }
        if (line.trim() === '') {
          return <br key={i} />;
        }
        // Handle inline formatting
        const formattedLine = line
          .replace(/\*\*(.+?)\*\*/g, '<strong class="text-foreground font-semibold">$1</strong>')
          .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" class="text-primary hover:underline">$1</a>');
        
        return (
          <p 
            key={i} 
            className="text-muted-foreground leading-relaxed mb-4"
            dangerouslySetInnerHTML={{ __html: formattedLine }}
          />
        );
      })
      .filter(Boolean);
  };

  return (
    <Layout>
      {/* Hero */}
      <section className="pt-32 pb-12 md:pt-40 md:pb-16">
        <div className="container-custom px-4 md:px-8">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto"
          >
            {/* Back Link */}
            <Link 
              to="/blog" 
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-8"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Blog
            </Link>

            {/* Category & Meta */}
            <div className="flex flex-wrap items-center gap-4 mb-6">
              <span className="px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
                {post.category}
              </span>
              <span className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="w-4 h-4" />
                {post.readTime}
              </span>
              <span className="flex items-center gap-2 text-sm text-muted-foreground">
                <Calendar className="w-4 h-4" />
                {post.date}
              </span>
            </div>

            {/* Title */}
            <h1 className="text-3xl md:text-5xl font-heading font-bold mb-6 leading-tight">
              {post.title}
            </h1>

            {/* Author */}
            <div className="flex items-center gap-4 pb-8 border-b border-border">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="font-medium text-foreground">{post.author.name}</p>
                <p className="text-sm text-muted-foreground">{post.author.role}</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Content */}
      <section className="pb-16">
        <div className="container-custom px-4 md:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="grid lg:grid-cols-[1fr_80px] gap-8">
              {/* Article Content */}
              <motion.article
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="prose prose-lg max-w-none"
              >
                {/* Featured Image Placeholder */}
                <div className="aspect-video rounded-2xl bg-gradient-to-br from-primary/20 to-accent/10 mb-10 flex items-center justify-center overflow-hidden">
                  <span className="text-8xl font-heading font-bold text-primary/20">
                    {post.id}
                  </span>
                </div>

                {/* Article Body */}
                <div className="space-y-1">
                  {formatContent(post.content)}
                </div>
              </motion.article>

              {/* Floating Share Sidebar - Desktop */}
              <motion.aside
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
                className="hidden lg:block"
              >
                <div className="sticky top-32 space-y-3">
                  <p className="text-xs text-muted-foreground uppercase tracking-wider mb-4">Share</p>
                  
                  <a
                    href={shareLinks.twitter}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center hover:bg-primary hover:border-primary hover:text-primary-foreground transition-all"
                    aria-label="Share on Twitter"
                  >
                    <Twitter className="w-4 h-4" />
                  </a>
                  
                  <a
                    href={shareLinks.facebook}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center hover:bg-primary hover:border-primary hover:text-primary-foreground transition-all"
                    aria-label="Share on Facebook"
                  >
                    <Facebook className="w-4 h-4" />
                  </a>
                  
                  <a
                    href={shareLinks.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center hover:bg-primary hover:border-primary hover:text-primary-foreground transition-all"
                    aria-label="Share on LinkedIn"
                  >
                    <Linkedin className="w-4 h-4" />
                  </a>
                  
                  <a
                    href={shareLinks.email}
                    className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center hover:bg-primary hover:border-primary hover:text-primary-foreground transition-all"
                    aria-label="Share via Email"
                  >
                    <Mail className="w-4 h-4" />
                  </a>
                  
                  <button
                    onClick={handleCopyLink}
                    className={`w-10 h-10 rounded-full border flex items-center justify-center transition-all ${
                      copied 
                        ? 'bg-green-500 border-green-500 text-white' 
                        : 'bg-card border-border hover:bg-primary hover:border-primary hover:text-primary-foreground'
                    }`}
                    aria-label="Copy link"
                  >
                    <Link2 className="w-4 h-4" />
                  </button>
                </div>
              </motion.aside>
            </div>

            {/* Mobile Share Bar */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="lg:hidden mt-12 p-6 rounded-2xl bg-card border border-border"
            >
              <p className="text-sm text-muted-foreground mb-4">Share this article</p>
              <div className="flex items-center gap-3">
                <a
                  href={shareLinks.twitter}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 h-12 rounded-xl bg-secondary flex items-center justify-center gap-2 hover:bg-primary hover:text-primary-foreground transition-all"
                >
                  <Twitter className="w-5 h-5" />
                </a>
                <a
                  href={shareLinks.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 h-12 rounded-xl bg-secondary flex items-center justify-center gap-2 hover:bg-primary hover:text-primary-foreground transition-all"
                >
                  <Facebook className="w-5 h-5" />
                </a>
                <a
                  href={shareLinks.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 h-12 rounded-xl bg-secondary flex items-center justify-center gap-2 hover:bg-primary hover:text-primary-foreground transition-all"
                >
                  <Linkedin className="w-5 h-5" />
                </a>
                <button
                  onClick={handleCopyLink}
                  className={`flex-1 h-12 rounded-xl flex items-center justify-center gap-2 transition-all ${
                    copied ? 'bg-green-500 text-white' : 'bg-secondary hover:bg-primary hover:text-primary-foreground'
                  }`}
                >
                  <Link2 className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Author Box */}
      <section className="pb-16">
        <div className="container-custom px-4 md:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-4xl mx-auto"
          >
            <div className="p-8 rounded-2xl bg-secondary/30 border border-border">
              <div className="flex items-start gap-6">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0">
                  <User className="w-10 h-10 text-white" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Written by</p>
                  <h3 className="text-xl font-heading font-bold mb-1">{post.author.name}</h3>
                  <p className="text-primary text-sm mb-3">{post.author.role}</p>
                  <p className="text-muted-foreground text-sm">
                    Expert in digital marketing strategy with years of experience helping brands 
                    achieve sustainable growth through data-driven campaigns.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Related Posts */}
      {relatedPosts.length > 0 && (
        <section className="pb-20">
          <div className="container-custom px-4 md:px-8">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-2xl md:text-3xl font-heading font-bold mb-8">Related Articles</h2>
              
              <div className="grid md:grid-cols-3 gap-8">
                {relatedPosts.map((relatedPost, index) => (
                  <motion.article
                    key={relatedPost.id}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="group"
                  >
                    <Link to={`/blog/${relatedPost.slug}`} className="block">
                      <div className="aspect-video rounded-2xl bg-card border border-border mb-4 overflow-hidden flex items-center justify-center group-hover:border-primary/50 transition-colors">
                        <span className="text-4xl font-heading font-bold text-muted-foreground/20">
                          {relatedPost.id}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-sm text-muted-foreground mb-2">
                        <span className="text-xs">{relatedPost.category}</span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {relatedPost.readTime}
                        </span>
                      </div>
                      <h3 className="text-lg font-heading font-semibold mb-2 group-hover:text-primary transition-colors">
                        {relatedPost.title}
                      </h3>
                      <p className="text-sm text-muted-foreground line-clamp-2">{relatedPost.excerpt}</p>
                    </Link>
                  </motion.article>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="pb-20">
        <div className="container-custom px-4 md:px-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="max-w-4xl mx-auto rounded-3xl bg-gradient-to-r from-primary/20 to-accent/20 p-12 text-center"
          >
            <h2 className="text-2xl md:text-3xl font-heading font-bold mb-4">
              Ready to Grow Your Business?
            </h2>
            <p className="text-muted-foreground mb-8 max-w-lg mx-auto">
              Let's discuss how we can help you implement these strategies and achieve real results.
            </p>
            <Button variant="hero" size="lg" asChild>
              <Link to="/contact">
                Get a Free Strategy Call
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default BlogPost;
