import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Target, Users, Lightbulb, Heart, Award, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Layout from '@/components/layout/Layout';

const fadeInUp = {
  initial: { opacity: 0, y: 40 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

const values = [
  {
    icon: Target,
    title: 'Results-Driven',
    description: 'Every strategy is crafted with measurable outcomes in mind. We don\'t just aim for engagement—we aim for growth.',
  },
  {
    icon: Lightbulb,
    title: 'Innovation First',
    description: 'We stay ahead of trends and constantly explore new technologies to give our clients a competitive edge.',
  },
  {
    icon: Heart,
    title: 'Client Partnership',
    description: 'We treat your business as our own, building long-term relationships based on trust and mutual success.',
  },
  {
    icon: Users,
    title: 'Collaborative Spirit',
    description: 'Our diverse team brings together creativity, strategy, and technical expertise for holistic solutions.',
  },
];

const team = [
  {
    name: 'Alex Rivera',
    role: 'Founder & CEO',
    bio: 'Former Google strategist with 15+ years in digital marketing.',
  },
  {
    name: 'Jordan Kim',
    role: 'Creative Director',
    bio: 'Award-winning designer passionate about brand storytelling.',
  },
  {
    name: 'Sam Patel',
    role: 'Head of Strategy',
    bio: 'Data scientist turned marketer, obsessed with performance metrics.',
  },
  {
    name: 'Maya Chen',
    role: 'Social Media Lead',
    bio: 'Built communities of 1M+ for Fortune 500 brands.',
  },
];

const About = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="pt-32 pb-20 md:pt-40 md:pb-28">
        <div className="container-custom px-4 md:px-8">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <span className="text-primary font-medium mb-4 block">About Norify</span>
            <h1 className="text-4xl md:text-6xl font-heading font-bold mb-8">
              We're on a Mission to{' '}
              <span className="gradient-text">Transform Digital Growth</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Founded in 2019, Norify has grown from a small team of passionate marketers 
              to a full-service digital agency helping brands worldwide achieve extraordinary results.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 bg-secondary/30 border-y border-border">
        <div className="container-custom px-4 md:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-heading font-bold mb-6">Our Story</h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  Norify was born from a simple observation: too many businesses were investing 
                  in digital marketing without seeing real returns. We set out to change that.
                </p>
                <p>
                  Our founder, Alex Rivera, left a successful career at Google to build an agency 
                  that prioritized measurable results over vanity metrics. What started as a 
                  three-person team working from a co-working space has evolved into a team of 
                  25+ specialists serving clients across the globe.
                </p>
                <p>
                  Today, we've helped generate over $10 million in revenue for our clients, 
                  launched hundreds of successful campaigns, and built a reputation for 
                  delivering exceptional results.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="grid grid-cols-2 gap-4"
            >
              {[
                { value: '2019', label: 'Founded' },
                { value: '25+', label: 'Team Members' },
                { value: '500+', label: 'Projects' },
                { value: '15+', label: 'Countries' },
              ].map((stat, index) => (
                <div key={stat.label} className="p-6 rounded-2xl bg-card border border-border text-center">
                  <div className="text-3xl md:text-4xl font-heading font-bold gradient-text mb-2">
                    {stat.value}
                  </div>
                  <p className="text-muted-foreground">{stat.label}</p>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="p-8 md:p-12 rounded-3xl bg-gradient-to-br from-primary/10 to-transparent border border-primary/20"
            >
              <div className="w-14 h-14 rounded-xl bg-primary/20 flex items-center justify-center mb-6">
                <Target className="w-7 h-7 text-primary" />
              </div>
              <h3 className="text-2xl md:text-3xl font-heading font-bold mb-4">Our Mission</h3>
              <p className="text-muted-foreground text-lg leading-relaxed">
                To empower businesses with innovative digital strategies that drive sustainable growth, 
                build meaningful connections, and deliver measurable ROI.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="p-8 md:p-12 rounded-3xl bg-gradient-to-br from-accent/10 to-transparent border border-accent/20"
            >
              <div className="w-14 h-14 rounded-xl bg-accent/20 flex items-center justify-center mb-6">
                <TrendingUp className="w-7 h-7 text-accent" />
              </div>
              <h3 className="text-2xl md:text-3xl font-heading font-bold mb-4">Our Vision</h3>
              <p className="text-muted-foreground text-lg leading-relaxed">
                To become the most trusted digital growth partner for ambitious brands, 
                setting the standard for excellence in performance marketing.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="section-padding bg-secondary/30">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <span className="text-primary font-medium mb-4 block">Our Values</span>
            <h2 className="text-3xl md:text-5xl font-heading font-bold">
              What <span className="gradient-text">Drives Us</span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="p-6 rounded-2xl bg-card border border-border text-center"
              >
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <value.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-heading font-semibold mb-2">{value.title}</h3>
                <p className="text-sm text-muted-foreground">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="section-padding">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <span className="text-primary font-medium mb-4 block">Meet The Team</span>
            <h2 className="text-3xl md:text-5xl font-heading font-bold">
              The People Behind <span className="gradient-text">Norify</span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {team.map((member, index) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group"
              >
                <div className="aspect-square rounded-2xl bg-gradient-to-br from-primary/20 to-accent/10 mb-4 overflow-hidden">
                  <div className="w-full h-full flex items-center justify-center text-6xl font-heading font-bold text-primary/30">
                    {member.name.charAt(0)}
                  </div>
                </div>
                <h3 className="text-xl font-heading font-semibold">{member.name}</h3>
                <p className="text-primary text-sm mb-2">{member.role}</p>
                <p className="text-sm text-muted-foreground">{member.bio}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Awards */}
      <section className="py-16 bg-secondary/30 border-y border-border">
        <div className="container-custom px-4 md:px-8">
          <div className="flex flex-col md:flex-row items-center justify-center gap-8 md:gap-16">
            {[
              'Agency of the Year 2023',
              'Best Performance Campaign',
              'Top Digital Innovator',
            ].map((award) => (
              <div key={award} className="flex items-center gap-3 text-muted-foreground">
                <Award className="w-5 h-5 text-primary" />
                <span className="font-medium">{award}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-padding">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-3xl mx-auto"
          >
            <h2 className="text-3xl md:text-5xl font-heading font-bold mb-6">
              Ready to Work With Us?
            </h2>
            <p className="text-lg text-muted-foreground mb-10">
              Join the hundreds of brands that trust Norify to drive their digital growth.
            </p>
            <Button variant="hero" size="lg" asChild>
              <Link to="/contact">
                Let's Talk
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default About;
