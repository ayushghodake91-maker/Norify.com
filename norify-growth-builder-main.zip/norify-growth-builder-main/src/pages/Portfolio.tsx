import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, TrendingUp, Users, DollarSign, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Layout from '@/components/layout/Layout';

const categories = ['All', 'E-Commerce', 'SaaS', 'B2B', 'Lifestyle'];

const projects = [
  {
    id: 1,
    title: 'StyleHouse E-Commerce Growth',
    category: 'E-Commerce',
    client: 'StyleHouse',
    description: 'Scaled a fashion e-commerce brand from $50K to $500K monthly revenue through strategic paid advertising and conversion optimization.',
    metrics: [
      { icon: TrendingUp, value: '900%', label: 'Revenue Growth' },
      { icon: Users, value: '250K', label: 'New Customers' },
      { icon: DollarSign, value: '4.2x', label: 'ROAS' },
    ],
    services: ['Performance Ads', 'SEO', 'Email Marketing'],
    testimonial: {
      quote: "Norify transformed our business. We went from struggling to scale to having our best year ever.",
      author: "Emma Williams",
      role: "Founder, StyleHouse"
    }
  },
  {
    id: 2,
    title: 'TechStart B2B Lead Generation',
    category: 'SaaS',
    client: 'TechStart Inc.',
    description: 'Developed a multi-channel B2B lead generation strategy that delivered a consistent pipeline of qualified enterprise leads.',
    metrics: [
      { icon: TrendingUp, value: '300%', label: 'Lead Increase' },
      { icon: Users, value: '500+', label: 'Enterprise Leads' },
      { icon: DollarSign, value: '60%', label: 'Lower CAC' },
    ],
    services: ['LinkedIn Ads', 'Content Marketing', 'SEO'],
    testimonial: {
      quote: "The quality of leads we receive now is exceptional. Our sales team is closing deals faster than ever.",
      author: "Sarah Chen",
      role: "CEO, TechStart Inc."
    }
  },
  {
    id: 3,
    title: 'Bloom Co. Brand Launch',
    category: 'Lifestyle',
    client: 'Bloom Co.',
    description: 'Complete brand strategy and digital launch for a wellness startup, building awareness from zero to 100K+ social followers.',
    metrics: [
      { icon: TrendingUp, value: '100K+', label: 'Followers' },
      { icon: Users, value: '5M+', label: 'Impressions' },
      { icon: DollarSign, value: '85%', label: 'Engagement Rate' },
    ],
    services: ['Branding', 'Social Media', 'Influencer Marketing'],
    testimonial: {
      quote: "Norify didn't just build our brand—they built a community. The engagement we see daily is incredible.",
      author: "Michael Torres",
      role: "Marketing Director, Bloom Co."
    }
  },
  {
    id: 4,
    title: 'MetaWave SaaS Conversion',
    category: 'SaaS',
    client: 'MetaWave',
    description: 'Increased trial-to-paid conversion rate by 150% through strategic funnel optimization and onboarding improvements.',
    metrics: [
      { icon: TrendingUp, value: '150%', label: 'Conversion Lift' },
      { icon: Users, value: '40%', label: 'Churn Reduction' },
      { icon: DollarSign, value: '$2M+', label: 'ARR Added' },
    ],
    services: ['CRO', 'Email Marketing', 'Product Marketing'],
    testimonial: {
      quote: "The insights and optimizations Norify implemented fundamentally changed our growth trajectory.",
      author: "David Park",
      role: "Head of Growth, MetaWave"
    }
  },
  {
    id: 5,
    title: 'Quantum Inc. Enterprise Campaign',
    category: 'B2B',
    client: 'Quantum Inc.',
    description: 'Account-based marketing campaign targeting Fortune 500 companies, resulting in 12 enterprise deals closed.',
    metrics: [
      { icon: TrendingUp, value: '12', label: 'Enterprise Deals' },
      { icon: Users, value: '85%', label: 'Target Account Reach' },
      { icon: DollarSign, value: '$5M+', label: 'Pipeline Value' },
    ],
    services: ['ABM', 'LinkedIn', 'Content Strategy'],
    testimonial: {
      quote: "Their ABM approach helped us land our biggest clients. Worth every penny.",
      author: "Lisa Johnson",
      role: "CMO, Quantum Inc."
    }
  },
  {
    id: 6,
    title: 'Luxe Beauty E-Commerce',
    category: 'E-Commerce',
    client: 'Luxe Beauty',
    description: 'Rebuilt paid media strategy and achieved profitability within 90 days for a struggling beauty brand.',
    metrics: [
      { icon: TrendingUp, value: '400%', label: 'Revenue Growth' },
      { icon: Users, value: '3.8x', label: 'ROAS' },
      { icon: DollarSign, value: '90 days', label: 'To Profitability' },
    ],
    services: ['Meta Ads', 'Google Ads', 'Email'],
    testimonial: {
      quote: "We were about to shut down. Norify turned us profitable in 90 days.",
      author: "Amanda Lee",
      role: "Founder, Luxe Beauty"
    }
  },
];

const Portfolio = () => {
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredProjects = activeCategory === 'All' 
    ? projects 
    : projects.filter(p => p.category === activeCategory);

  return (
    <Layout>
      {/* Hero */}
      <section className="pt-32 pb-20 md:pt-40 md:pb-28">
        <div className="container-custom px-4 md:px-8">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <span className="text-primary font-medium mb-4 block">Our Work</span>
            <h1 className="text-4xl md:text-6xl font-heading font-bold mb-8">
              Case Studies & <span className="gradient-text">Success Stories</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Real results from real clients. Explore how we've helped brands 
              across industries achieve extraordinary growth.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filters */}
      <section className="pb-12">
        <div className="container-custom px-4 md:px-8">
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  activeCategory === category
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-muted-foreground hover:bg-secondary/80 hover:text-foreground'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="pb-20">
        <div className="container-custom px-4 md:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            {filteredProjects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="group rounded-3xl bg-card border border-border overflow-hidden hover:border-primary/50 transition-all duration-300"
              >
                {/* Project Header */}
                <div className="aspect-video bg-gradient-to-br from-primary/20 to-accent/10 flex items-center justify-center">
                  <span className="text-4xl md:text-5xl font-heading font-bold text-primary/30">
                    {project.client.charAt(0)}
                  </span>
                </div>

                {/* Project Content */}
                <div className="p-8">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium">
                      {project.category}
                    </span>
                    <span className="text-sm text-muted-foreground">{project.client}</span>
                  </div>

                  <h3 className="text-xl md:text-2xl font-heading font-bold mb-3">
                    {project.title}
                  </h3>
                  <p className="text-muted-foreground mb-6">{project.description}</p>

                  {/* Metrics */}
                  <div className="grid grid-cols-3 gap-4 mb-6 p-4 rounded-xl bg-secondary/50">
                    {project.metrics.map((metric) => (
                      <div key={metric.label} className="text-center">
                        <div className="text-xl md:text-2xl font-heading font-bold gradient-text">
                          {metric.value}
                        </div>
                        <p className="text-xs text-muted-foreground">{metric.label}</p>
                      </div>
                    ))}
                  </div>

                  {/* Services */}
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.services.map((service) => (
                      <span key={service} className="px-3 py-1 rounded-full bg-muted text-muted-foreground text-xs">
                        {service}
                      </span>
                    ))}
                  </div>

                  {/* Testimonial */}
                  <div className="p-4 rounded-xl bg-muted/50 border-l-2 border-primary">
                    <p className="text-sm italic text-foreground mb-2">"{project.testimonial.quote}"</p>
                    <p className="text-xs text-muted-foreground">
                      — {project.testimonial.author}, {project.testimonial.role}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-padding bg-secondary/30 border-t border-border">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-3xl mx-auto"
          >
            <h2 className="text-3xl md:text-5xl font-heading font-bold mb-6">
              Want Results Like These?
            </h2>
            <p className="text-lg text-muted-foreground mb-10">
              Let's discuss how we can help your brand achieve similar success.
            </p>
            <Button variant="hero" size="lg" asChild>
              <Link to="/contact">
                Start Your Success Story
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default Portfolio;
