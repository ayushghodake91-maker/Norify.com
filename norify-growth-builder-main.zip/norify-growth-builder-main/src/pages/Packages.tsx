import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Check, Zap, Rocket, Crown, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Layout from '@/components/layout/Layout';

const packages = [
  {
    icon: Zap,
    name: 'Starter',
    description: 'Perfect for small businesses starting their digital journey.',
    price: '$2,500',
    period: '/month',
    popular: false,
    features: [
      'Social Media Management (2 platforms)',
      'Content Creation (12 posts/month)',
      'Basic Analytics & Reporting',
      'Monthly Strategy Call',
      'Email Support',
      'Brand Guidelines',
    ],
    notIncluded: [
      'Paid Advertising',
      'SEO Services',
      'Video Production',
    ],
    cta: 'Get Started',
  },
  {
    icon: Rocket,
    name: 'Growth',
    description: 'Ideal for growing businesses ready to scale their marketing.',
    price: '$5,000',
    period: '/month',
    popular: true,
    features: [
      'Social Media Management (4 platforms)',
      'Content Creation (24 posts/month)',
      'Paid Ad Management ($5K-$15K spend)',
      'SEO & Content Marketing',
      'Advanced Analytics Dashboard',
      'Bi-weekly Strategy Calls',
      'Priority Email & Slack Support',
      'A/B Testing & Optimization',
    ],
    notIncluded: [
      'Video Production',
      'Influencer Marketing',
    ],
    cta: 'Start Growing',
  },
  {
    icon: Crown,
    name: 'Enterprise',
    description: 'Full-service solution for established brands seeking market dominance.',
    price: '$10,000',
    period: '/month',
    popular: false,
    features: [
      'Unlimited Platform Management',
      'Premium Content Creation',
      'Paid Ad Management (Unlimited)',
      'Full SEO & Content Strategy',
      'Video Production (4/month)',
      'Influencer Partnership Management',
      'Dedicated Account Manager',
      'Weekly Strategy Sessions',
      '24/7 Priority Support',
      'Custom Reporting & Attribution',
      'Conversion Rate Optimization',
      'Brand Reputation Management',
    ],
    notIncluded: [],
    cta: 'Contact Sales',
  },
];

const addOns = [
  {
    name: 'Video Production',
    description: 'Professional video content for ads and social',
    price: 'From $1,500/video',
  },
  {
    name: 'Influencer Campaigns',
    description: 'End-to-end influencer partnership management',
    price: 'From $3,000/campaign',
  },
  {
    name: 'Website Development',
    description: 'Custom landing pages and website builds',
    price: 'From $5,000',
  },
  {
    name: 'Email Marketing',
    description: 'Strategy, automation, and campaign management',
    price: 'From $1,000/month',
  },
];

const Packages = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="pt-32 pb-20 md:pt-40 md:pb-28">
        <div className="container-custom px-4 md:px-8">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <span className="text-primary font-medium mb-4 block">Pricing</span>
            <h1 className="text-4xl md:text-6xl font-heading font-bold mb-8">
              Transparent <span className="gradient-text">Packages</span> for Every Stage
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Choose the plan that fits your business needs. All packages include 
              dedicated support and measurable results.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Packages Grid */}
      <section className="pb-20">
        <div className="container-custom px-4 md:px-8">
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {packages.map((pkg, index) => (
              <motion.div
                key={pkg.name}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={`relative rounded-3xl p-8 ${
                  pkg.popular
                    ? 'bg-gradient-to-b from-primary/20 to-card border-2 border-primary'
                    : 'bg-card border border-border'
                }`}
              >
                {pkg.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                    <span className="inline-flex items-center gap-1 px-4 py-1 rounded-full bg-primary text-primary-foreground text-sm font-medium">
                      <Star className="w-4 h-4" /> Most Popular
                    </span>
                  </div>
                )}

                <div className="text-center mb-8">
                  <div className={`w-14 h-14 rounded-xl ${pkg.popular ? 'bg-primary/20' : 'bg-muted'} flex items-center justify-center mx-auto mb-4`}>
                    <pkg.icon className={`w-7 h-7 ${pkg.popular ? 'text-primary' : 'text-muted-foreground'}`} />
                  </div>
                  <h3 className="text-2xl font-heading font-bold mb-2">{pkg.name}</h3>
                  <p className="text-sm text-muted-foreground mb-6">{pkg.description}</p>
                  <div className="flex items-baseline justify-center gap-1">
                    <span className="text-4xl md:text-5xl font-heading font-bold">{pkg.price}</span>
                    <span className="text-muted-foreground">{pkg.period}</span>
                  </div>
                </div>

                <div className="space-y-3 mb-8">
                  {pkg.features.map((feature) => (
                    <div key={feature} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                <Button
                  variant={pkg.popular ? 'hero' : 'outline'}
                  className="w-full"
                  size="lg"
                  asChild
                >
                  <Link to="/contact">
                    {pkg.cta}
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Add-ons */}
      <section className="py-20 bg-secondary/30 border-y border-border">
        <div className="container-custom px-4 md:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-heading font-bold">
              Optional <span className="gradient-text">Add-Ons</span>
            </h2>
            <p className="text-muted-foreground mt-4">Enhance your package with additional services</p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
            {addOns.map((addon, index) => (
              <motion.div
                key={addon.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="p-6 rounded-2xl bg-card border border-border"
              >
                <h4 className="font-heading font-semibold mb-2">{addon.name}</h4>
                <p className="text-sm text-muted-foreground mb-4">{addon.description}</p>
                <p className="text-sm font-medium text-primary">{addon.price}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="section-padding">
        <div className="container-custom max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-heading font-bold">
              Common <span className="gradient-text">Questions</span>
            </h2>
          </motion.div>

          <div className="space-y-6">
            {[
              {
                q: 'What\'s the minimum contract length?',
                a: 'We recommend a minimum of 3 months to see meaningful results, but we offer month-to-month flexibility after the initial period.',
              },
              {
                q: 'Can I switch packages?',
                a: 'Absolutely! You can upgrade or adjust your package at any time. We\'ll help you find the right fit as your needs evolve.',
              },
              {
                q: 'What\'s included in ad spend?',
                a: 'Ad spend is separate from our management fee. We handle strategy, creative, and optimization—you control the budget.',
              },
              {
                q: 'How do you report results?',
                a: 'You\'ll get access to a real-time dashboard plus monthly/bi-weekly reports depending on your package, with clear metrics tied to your goals.',
              },
            ].map((faq, index) => (
              <motion.div
                key={faq.q}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="p-6 rounded-2xl bg-card border border-border"
              >
                <h4 className="font-heading font-semibold mb-2">{faq.q}</h4>
                <p className="text-muted-foreground">{faq.a}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-padding bg-secondary/30 border-t border-border">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-3xl mx-auto"
          >
            <h2 className="text-3xl md:text-5xl font-heading font-bold mb-6">
              Need a Custom Solution?
            </h2>
            <p className="text-lg text-muted-foreground mb-10">
              Let's build a package tailored to your specific needs and goals.
            </p>
            <Button variant="hero" size="lg" asChild>
              <Link to="/contact">
                Request Custom Quote
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default Packages;
