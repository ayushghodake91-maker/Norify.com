import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Target, TrendingUp, Megaphone, Search, Palette, Globe, ChevronRight, Star, Users, Award, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Layout from '@/components/layout/Layout';
import heroBg from '@/assets/hero-bg.jpg';

const fadeInUp = {
  initial: { opacity: 0, y: 40 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

const services = [
  {
    icon: Target,
    title: 'Digital Strategy',
    description: 'Data-driven strategies that align with your business goals and drive measurable growth.',
  },
  {
    icon: Megaphone,
    title: 'Social Media Marketing',
    description: 'Engaging content and community management that builds authentic brand connections.',
  },
  {
    icon: TrendingUp,
    title: 'Performance Ads',
    description: 'ROI-focused campaigns across Meta, Google, and emerging platforms.',
  },
  {
    icon: Search,
    title: 'SEO & Content',
    description: 'Strategic content that ranks and converts organic traffic into customers.',
  },
  {
    icon: Palette,
    title: 'Branding & Design',
    description: 'Visual identities that capture your essence and resonate with your audience.',
  },
  {
    icon: Globe,
    title: 'Website Optimization',
    description: 'Conversion-focused funnels that turn visitors into loyal customers.',
  },
];

const stats = [
  { value: '500+', label: 'Projects Delivered' },
  { value: '98%', label: 'Client Satisfaction' },
  { value: '10M+', label: 'Revenue Generated' },
  { value: '50+', label: 'Active Clients' },
];

const testimonials = [
  {
    quote: "Norify transformed our digital presence. Our leads increased by 300% in just 6 months.",
    author: "Sarah Chen",
    role: "CEO, TechStart Inc.",
    rating: 5,
  },
  {
    quote: "The team's strategic approach and creativity exceeded all our expectations. Highly recommended.",
    author: "Michael Torres",
    role: "Marketing Director, Bloom Co.",
    rating: 5,
  },
  {
    quote: "Working with Norify has been a game-changer for our e-commerce brand. Sales are through the roof!",
    author: "Emma Williams",
    role: "Founder, StyleHouse",
    rating: 5,
  },
];

const clients = [
  'TechCorp', 'Innovate Labs', 'Bloom Co.', 'StyleHouse', 'MetaWave', 'Quantum Inc.'
];

const Index = () => {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 z-0">
          <img
            src={heroBg}
            alt="Digital marketing visualization"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background" />
          <div className="absolute inset-0 bg-gradient-radial from-primary/10 via-transparent to-transparent" />
        </div>

        {/* Content */}
        <div className="container-custom relative z-10 px-4 md:px-8 pt-20">
          <motion.div
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-5xl mx-auto"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-8"
            >
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Driving Growth Since 2019</span>
            </motion.div>

            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-heading font-bold leading-tight mb-8">
              Transform Your Brand With{' '}
              <span className="gradient-text glow-text">Digital Excellence</span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-12 leading-relaxed">
              We craft data-driven marketing strategies that amplify your presence, 
              engage your audience, and accelerate your growth in the digital landscape.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button variant="hero" size="lg" asChild>
                <Link to="/contact">
                  Start Your Growth Journey
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Link>
              </Button>
              <Button variant="glass" size="lg" asChild>
                <Link to="/portfolio">
                  View Our Work
                </Link>
              </Button>
            </div>
          </motion.div>

          {/* Scroll Indicator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2 }}
            className="absolute bottom-12 left-1/2 -translate-x-1/2"
          >
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="w-6 h-10 rounded-full border-2 border-muted-foreground/30 flex justify-center pt-2"
            >
              <div className="w-1.5 h-2.5 rounded-full bg-primary" />
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Trusted By Section */}
      <section className="py-16 border-y border-border bg-secondary/30">
        <div className="container-custom px-4 md:px-8">
          <p className="text-center text-muted-foreground mb-8">Trusted by leading brands</p>
          <div className="flex flex-wrap items-center justify-center gap-8 md:gap-16">
            {clients.map((client) => (
              <span key={client} className="text-xl md:text-2xl font-heading font-semibold text-muted-foreground/50">
                {client}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="section-padding" id="services">
        <div className="container-custom">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="text-center mb-16"
          >
            <motion.span
              variants={fadeInUp}
              className="inline-block text-primary font-medium mb-4"
            >
              What We Do
            </motion.span>
            <motion.h2
              variants={fadeInUp}
              className="text-3xl md:text-5xl font-heading font-bold mb-6"
            >
              Services That <span className="gradient-text">Drive Results</span>
            </motion.h2>
            <motion.p
              variants={fadeInUp}
              className="text-muted-foreground text-lg max-w-2xl mx-auto"
            >
              Comprehensive digital marketing solutions tailored to your unique business needs.
            </motion.p>
          </motion.div>

          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                variants={fadeInUp}
                className="group p-8 rounded-2xl bg-card border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-[0_0_40px_hsl(262,83%,58%,0.1)]"
              >
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                  <service.icon className="w-7 h-7 text-primary" />
                </div>
                <h3 className="text-xl font-heading font-semibold mb-3">{service.title}</h3>
                <p className="text-muted-foreground mb-4">{service.description}</p>
                <Link
                  to="/services"
                  className="inline-flex items-center text-primary font-medium hover:gap-2 transition-all"
                >
                  Learn More <ChevronRight className="w-4 h-4 ml-1" />
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-secondary/30 border-y border-border">
        <div className="container-custom px-4 md:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl md:text-5xl font-heading font-bold gradient-text mb-2">
                  {stat.value}
                </div>
                <p className="text-muted-foreground">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <span className="text-primary font-medium mb-4 block">Why Norify</span>
              <h2 className="text-3xl md:text-5xl font-heading font-bold mb-6">
                Your Partner in <span className="gradient-text">Digital Success</span>
              </h2>
              <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
                We combine creative excellence with data-driven insights to deliver 
                marketing solutions that don't just look great—they perform.
              </p>

              <div className="space-y-6">
                {[
                  { icon: Users, title: 'Expert Team', desc: 'Strategists, creatives, and analysts working as one.' },
                  { icon: TrendingUp, title: 'Proven Results', desc: 'Track record of delivering measurable ROI.' },
                  { icon: Award, title: 'Award-Winning', desc: 'Recognized for creative excellence and innovation.' },
                ].map((item) => (
                  <div key={item.title} className="flex gap-4">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                      <item.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-heading font-semibold mb-1">{item.title}</h4>
                      <p className="text-muted-foreground">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="aspect-square rounded-3xl bg-gradient-to-br from-primary/20 to-accent/20 p-1">
                <div className="w-full h-full rounded-3xl bg-card flex items-center justify-center">
                  <div className="text-center p-8">
                    <div className="text-7xl md:text-8xl font-heading font-bold gradient-text mb-4">5+</div>
                    <p className="text-xl text-muted-foreground">Years of Excellence</p>
                  </div>
                </div>
              </div>
              <div className="absolute -bottom-6 -right-6 w-32 h-32 rounded-2xl bg-primary/20 blur-3xl" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section-padding bg-secondary/30">
        <div className="container-custom">
          <motion.div
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="text-center mb-16"
          >
            <motion.span variants={fadeInUp} className="text-primary font-medium mb-4 block">
              Testimonials
            </motion.span>
            <motion.h2 variants={fadeInUp} className="text-3xl md:text-5xl font-heading font-bold">
              What Our <span className="gradient-text">Clients Say</span>
            </motion.h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.author}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="p-8 rounded-2xl bg-card border border-border"
              >
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-foreground mb-6 leading-relaxed">"{testimonial.quote}"</p>
                <div>
                  <p className="font-heading font-semibold">{testimonial.author}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative rounded-3xl overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/20" />
            <div className="absolute inset-0 bg-[url('/pattern-bg.jpg')] opacity-10" />
            
            <div className="relative z-10 p-12 md:p-20 text-center">
              <h2 className="text-3xl md:text-5xl font-heading font-bold mb-6">
                Ready to <span className="gradient-text">Grow Your Brand?</span>
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10">
                Let's discuss how we can help you achieve your digital marketing goals. 
                Book a free strategy call with our team today.
              </p>
              <Button variant="hero" size="xl" asChild>
                <Link to="/contact">
                  Get a Free Strategy Call
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
